/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
import React from 'react'
import {Redirect} from 'umi'
export default function Index() {
    return (
       <Redirect to="/film"/>
    )
}
