/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
import React, { Component } from 'react'

export default class Films extends Component {
    render() {
        return (
            <div>
                films
            </div>
        )
    }
}
