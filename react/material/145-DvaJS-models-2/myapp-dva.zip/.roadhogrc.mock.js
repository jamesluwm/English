
const mockobj =  require('./mock/api')
export default {
    ...mockobj
};
