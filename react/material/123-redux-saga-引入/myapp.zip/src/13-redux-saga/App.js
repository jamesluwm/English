/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
import React, { Component } from 'react'
import './02-可执行生成器'
export default class App extends Component {
    render() {
        return (
            <div>
                App
            </div>
        )
    }
}
