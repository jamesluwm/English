/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
// console.log("hello world kerwin")
import React from 'react'
import ReactDOM from 'react-dom'

ReactDOM.render(<div>
    <b>11111111</b>
    <ul>
        <li>111</li>
        <li>111</li>
        <li>111</li>
        <li>111</li>
    </ul>
</div>,document.getElementById("root"))


/*
 jsx == js+xml
*/


