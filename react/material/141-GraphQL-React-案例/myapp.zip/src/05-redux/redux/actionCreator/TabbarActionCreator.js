/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */

 function hide(){
     return {
        type:"kerwinhide-tabbar"
    }
 }

 function show(){
    return {
        type:"kerwinshow-tabbar"
    }
 }

 export {show,hide}