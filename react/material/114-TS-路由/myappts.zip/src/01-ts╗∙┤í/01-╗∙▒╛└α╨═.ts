/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
 
 // 字符串， 数字， 布尔，

 var myname:string = "kerwin" 
 myname.substring(0,1)

 var myage:number = 100
 myage.toFixed(1)

 var myshow:boolean = true
 myshow = false 

 var my:string | number  ="kerwin"
 my = 100

 var myany:any = 100

 myany = "dwada"
 
 export default {}