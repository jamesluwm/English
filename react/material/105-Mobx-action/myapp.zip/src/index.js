/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
// console.log("hello world kerwin")
import React from 'react'
import ReactDOM from 'react-dom'

import App from './10-mobx/04-router/App'


ReactDOM.render(
    // <React.StrictMode>
    <App/>
    // </React.StrictMode>
    ,document.getElementById("root"))
