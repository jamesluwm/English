/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
import {Component} from 'react'
class Comingsoon extends Component{
    render(){
        return <div>
            Comingsoon
        </div>
    }
}

export default Comingsoon