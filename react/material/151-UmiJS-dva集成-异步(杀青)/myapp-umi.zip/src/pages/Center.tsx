/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
import React from 'react'

 function Center() {
    return (
        <div>
            Center
        </div>
    )
}
Center.wrappers = ["@/wrappers/Auth"]
export default Center
