// @ts-nocheck
import { Plugin } from 'E:/1-Kerwin/React/code/myapp-umi/node_modules/_@umijs_runtime@3.5.20@@umijs/runtime';

const plugin = new Plugin({
  validKeys: ['modifyClientRenderOpts','patchRoutes','rootContainer','render','onRouteChange','__mfsu','getInitialState','initialStateConfig','request',],
});

export { plugin };
