/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
import {Component} from 'react'
class Nowplaying extends Component{
    render(){
        return <div>
            Nowplaying
        </div>
    }
}

export default Nowplaying